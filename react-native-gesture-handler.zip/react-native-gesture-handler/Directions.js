import RNGestureHandlerModule from './RNGestureHandlerModule';

export default RNGestureHandlerModule.Direction;
