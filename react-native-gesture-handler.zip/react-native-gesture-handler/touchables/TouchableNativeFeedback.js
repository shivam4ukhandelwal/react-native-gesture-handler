import { TouchableNativeFeedback } from 'react-native';

export default TouchableNativeFeedback;
