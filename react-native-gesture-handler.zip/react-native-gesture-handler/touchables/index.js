export { default as TouchableNativeFeedback } from './TouchableNativeFeedback';
export {
  default as TouchableWithoutFeedback,
} from './TouchableWithoutFeedback';
export { default as TouchableOpacity } from './TouchableOpacity';
export { default as TouchableHighlight } from './TouchableHighlight';
