export default {
  RIGHT: 1,
  LEFT: 2,
  UP: 4,
  DOWN: 8,
};
