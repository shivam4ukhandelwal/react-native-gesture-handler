import { requireNativeComponent } from 'react-native';

const RNGestureHandlerButton = requireNativeComponent(
  'RNGestureHandlerButton',
  null
);

export default RNGestureHandlerButton;
