export default function Swipeable({ children }) {
  console.warn('Swipeable is not yet supported on web.');
  return children;
}
