jest.mock('./RNGestureHandlerModule');
