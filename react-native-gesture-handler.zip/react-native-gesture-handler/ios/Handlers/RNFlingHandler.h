#import "RNGestureHandler.h"

@interface RNFlingGestureHandler : RNGestureHandler
@end
