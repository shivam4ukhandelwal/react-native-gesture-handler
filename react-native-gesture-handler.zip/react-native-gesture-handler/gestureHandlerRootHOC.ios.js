export default function gestureHandlerRootHOC(Component) {
  // Empty implementation that just returns component directly,
  // GestureHandlerRootView is only required to be instantiated on Android
  return Component;
}
