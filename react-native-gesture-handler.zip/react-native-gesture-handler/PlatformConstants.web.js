export default {
  forceTouchAvailable: false,
};
