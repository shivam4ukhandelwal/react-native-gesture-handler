package com.swmansion.gesturehandler.react;

import javax.annotation.Nullable;

public interface RNGestureHandlerRootInterface {
  @Nullable RNGestureHandlerRootHelper getRootHelper();
}
