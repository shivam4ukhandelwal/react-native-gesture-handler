import { NativeModules } from 'react-native';

const { RNGestureHandlerModule } = NativeModules;

export default RNGestureHandlerModule;
